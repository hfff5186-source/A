#include <Geode/Geode.hpp>
#include <Geode/modify/EditorUI.hpp>
#include "tblib_engine.hpp"
#include <filesystem>

using namespace geode::prelude;

namespace {
    constexpr size_t OBJECTS_PER_FRAME = 90;

    autodeco::Bounds boundsFromArray(CCArray* array) {
        autodeco::Bounds b;
        if (!array) return b;
        for (unsigned i = 0; i < array->count(); ++i) {
            auto obj = typeinfo_cast<GameObject*>(array->objectAtIndex(i));
            if (!obj) continue;
            auto p = obj->getPosition();
            b.include(p.x, p.y);
        }
        return b;
    }

    std::filesystem::path builtInTemplate() {
        return Mod::get()->getResourcesDir() / "templates" / "tech_base.tblib";
    }

    std::filesystem::path customTemplateDir() {
        auto p = Mod::get()->getSaveDir() / "templates";
        std::error_code ec; std::filesystem::create_directories(p, ec);
        return p;
    }

}

class $modify(AutoDecoEditorUI, EditorUI) {
    struct Fields {
        std::vector<std::string> queue;
        size_t next = 0;
        bool running = false;
        CCLabelBMFont* progress = nullptr;
        std::vector<std::filesystem::path> templates;
        size_t templateIndex = 0;
    };

    bool init(LevelEditorLayer* layer) {
        if (!EditorUI::init(layer)) return false;
        auto size = CCDirector::sharedDirector()->getWinSize();
        auto menu = CCMenu::create();
        menu->setPosition({0, 0});
        menu->setID("autodeco-menu");
        auto add = [&](const char* text, SEL_MenuHandler fn, float y) {
            auto label = CCLabelBMFont::create(text, "bigFont.fnt");
            auto item = CCMenuItemLabel::create(label, this, fn);
            item->setScale(.42f);
            item->setPosition({size.width - 58.f, y});
            menu->addChild(item);
        };
        add("AUTO DECO", menu_selector(AutoDecoEditorUI::onInfo), size.height - 75.f);
        add("TEMPLATES", menu_selector(AutoDecoEditorUI::onTemplates), size.height - 105.f);
        add("FULL BUILD", menu_selector(AutoDecoEditorUI::onFullBuild), size.height - 135.f);
        add("SELECTED", menu_selector(AutoDecoEditorUI::onSelectedBuild), size.height - 165.f);
        this->addChild(menu, 1000);
        m_fields->templates.push_back(builtInTemplate());
        m_fields->templates.push_back(Mod::get()->getResourcesDir() / "templates" / "tech_temp.tblib");
        std::error_code templateEC;
        for (auto const& entry : std::filesystem::directory_iterator(customTemplateDir(), templateEC)) {
            if (templateEC) break;
            if (entry.is_regular_file() && entry.path().extension() == ".tblib")
                m_fields->templates.push_back(entry.path());
        }
        m_fields->progress = CCLabelBMFont::create("", "bigFont.fnt");
        m_fields->progress->setPosition({size.width / 2.f, size.height - 28.f});
        m_fields->progress->setScale(.45f);
        m_fields->progress->setVisible(false);
        this->addChild(m_fields->progress, 1001);
        return true;
    }

    void onInfo(CCObject*) {
        FLAlertLayer::create("Auto Deco", "Tech template engine\n\nFull Build fits the template to the level's existing object bounds. Selected applies it around the selected objects. Objects are inserted in small batches.", "OK")->show();
    }

    void onTemplates(CCObject*) {
        if (m_fields->templates.empty()) return;
        m_fields->templateIndex = (m_fields->templateIndex + 1) % m_fields->templates.size();
        auto const& selected = m_fields->templates[m_fields->templateIndex];
        auto message = "Selected template:\n" + selected.filename().string() +
            "\n\nTap TEMPLATES again to cycle through available .tblib files.\n" +
            "Copy more .tblib files into:\n" + customTemplateDir().string();
        FLAlertLayer::create("Template Selector", message.c_str(), "OK")->show();
    }

    void onFullBuild(CCObject*) {
        if (m_fields->running) return;
        auto all = m_editorLayer->getAllObjects();
        auto target = boundsFromArray(all);
        if (!target.valid) {
            FLAlertLayer::create("Auto Deco", "The level has no objects to determine its bounds. Add the level layout first, then run Auto Deco.", "OK")->show();
            return;
        }
        beginBuild(target);
    }

    void onSelectedBuild(CCObject*) {
        if (m_fields->running) return;
        auto selected = m_selectedObjects;
        auto target = boundsFromArray(selected);
        if (!target.valid) {
            FLAlertLayer::create("Auto Deco", "Select one or more objects in the editor first.", "OK")->show();
            return;
        }
        beginBuild(target);
    }

    void beginBuild(autodeco::Bounds const& target) {
        if (m_fields->templates.empty()) {
            FLAlertLayer::create("Auto Deco", "No TBLIB templates are available.", "OK")->show();
            return;
        }
        auto path = m_fields->templates[m_fields->templateIndex];
        auto data = autodeco::loadTemplate(path.string());
        if (!data) {
            FLAlertLayer::create("Auto Deco - Template Error", data.error.c_str(), "OK")->show();
            return;
        }
        auto generated = autodeco::generate(data, target);
        if (generated.empty()) {
            FLAlertLayer::create("Auto Deco", "No valid objects could be generated for this area.", "OK")->show();
            return;
        }
        m_fields->queue = std::move(generated);
        m_fields->next = 0;
        m_fields->running = true;
        m_fields->progress->setVisible(true);
        this->scheduleUpdate();
    }

    void update(float dt) {
        if (!m_fields->running) return;
        size_t end = std::min(m_fields->next + OBJECTS_PER_FRAME, m_fields->queue.size());
        for (; m_fields->next < end; ++m_fields->next) {
            m_editorLayer->addObjectFromString(m_fields->queue[m_fields->next]);
        }
        auto text = std::string("Auto Deco: ") + std::to_string(m_fields->next) + "/" + std::to_string(m_fields->queue.size());
        m_fields->progress->setString(text.c_str());
        if (m_fields->next >= m_fields->queue.size()) {
            m_fields->running = false;
            this->unscheduleUpdate();
            m_fields->progress->setVisible(false);
            m_fields->queue.clear();
            FLAlertLayer::create("Auto Deco", "Template placement finished. Save your level to keep the changes.", "OK")->show();
        }
    }
};
