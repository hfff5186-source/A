#!/usr/bin/env bash
set -euo pipefail

if ! command -v geode >/dev/null 2>&1; then
  echo "ERROR: Geode CLI is not installed or not in PATH."
  exit 1
fi
if [[ -z "${ANDROID_NDK_ROOT:-}" ]]; then
  echo "ERROR: ANDROID_NDK_ROOT is not set. Install Android NDK and set this variable."
  exit 1
fi

geode sdk install-binaries -p android64
geode build -p android64

echo "Build command completed. Look for the .geode package in build-android64/."
