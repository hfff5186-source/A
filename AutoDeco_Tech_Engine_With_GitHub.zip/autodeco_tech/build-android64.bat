@echo off
setlocal
where geode >nul 2>nul
if errorlevel 1 (
  echo ERROR: Geode CLI is not installed or not in PATH.
  exit /b 1
)
if "%ANDROID_NDK_ROOT%"=="" (
  echo ERROR: ANDROID_NDK_ROOT is not set. Install Android NDK and set this variable.
  exit /b 1
)
geode sdk install-binaries -p android64
if errorlevel 1 exit /b %errorlevel%
geode build -p android64
if errorlevel 1 exit /b %errorlevel%
echo Build command completed. Look for the .geode package in build-android64\.
endlocal
