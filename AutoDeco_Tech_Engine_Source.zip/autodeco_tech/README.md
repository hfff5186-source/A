# Auto Deco — Tech template engine

Geode C++ source project for Geometry Dash 2.2081 / Geode 5.6.1.

## Algorithm
- Reads the TBLIB 2 header and extracts serialized Geometry Dash object strings.
- Validates object ID and X/Y fields before accepting a record.
- Calculates the template and target bounds.
- Uniformly fits the template into the target bounds while preserving aspect ratio.
- Rewrites object X/Y pairs and inserts objects in small per-frame batches to avoid a single long blocking loop.
- Full Build uses the current level object's bounds. Selected Build uses the editor's selected-object bounds.

## Template import
Copy compatible `.tblib` files to the mod save folder's `templates` directory. The included Tech Base template is loaded by default. This first engine revision exposes the built-in Tech Base; choosing custom templates from an in-game picker is the next UI layer.

## Build
Use the Geode SDK and CLI matching the target game version. Configure CMake with `GEODE_SDK` set to the SDK directory, then build the `AutoDeco` target.

## Validation status
The standalone TBLIB parser is testable without Geometry Dash. The Geode integration still requires compilation against the exact installed SDK and runtime testing in the editor; no source-only project can honestly guarantee zero runtime bugs before that test. Work on a duplicate level first and save a backup before applying generated objects.

## Standalone parser check
The parser can be checked without the Geode SDK:

```sh
g++ -std=c++17 -O2 tests/tblib_validate.cpp -o tblib_validate
./tblib_validate resources/templates/tech_base.tblib resources/templates/tech_temp.tblib
```

The validation tool checks file structure, serialized object IDs and coordinates, and that every accepted object survives the placement transform.
