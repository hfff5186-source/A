# Auto Deco — Tech Template Prototype

Geode mod source project targeting Geometry Dash 2.2081 / Geode 5.6.1.

## Included
- Editor UI entry with buttons: AUTO DECO, TEMPLATE, FULL BUILD, SELECTED.
- The Tech `.tblib` base and temporary template files extracted from the user-provided Autobuild package.
- Custom `.tblib` discovery from the mod save folder: `geode/config/yousef.autodeco/templates/` (exact location depends on platform/Geode).
- Basic header validation (`TBLIB 2`).

## Important implementation status
This is an **initial source prototype**, not a finished Auto Deco generator. The buttons are wired to explanatory dialogs; Full Build and Selected Build do not place objects yet. The supplied `.tblib` files contain template data, but the generation algorithm that interprets/applies that data is not included in the uploaded `.geode` package as source code. A compatible generator must be implemented before those actions can work.

## Build
1. Install the Geode SDK matching Geode 5.6.1.
2. Configure with CMake and `GEODE_SDK` pointing to the SDK folder.
3. Build the `AutoDeco` target using the SDK's supported toolchain.

Do not rename the mod ID after installing unless you also update the save-folder path used for custom templates.
