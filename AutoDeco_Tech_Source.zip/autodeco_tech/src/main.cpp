#include <Geode/Geode.hpp>
#include <Geode/modify/EditorUI.hpp>
#include <filesystem>
#include <fstream>
#include <sstream>

using namespace geode::prelude;

namespace {
    bool hasTemplateFile(std::string const& name) {
        auto path = Mod::get()->getResourcesDir() / "templates" / name;
        std::ifstream file(path, std::ios::binary);
        if (!file) return false;
        std::string header;
        std::getline(file, header);
        return header == "TBLIB 2";
    }

    std::string listImportedTemplates() {
        std::ostringstream out;
        auto dir = Mod::get()->getSaveDir() / "templates";
        std::error_code ec;
        std::filesystem::create_directories(dir, ec);
        bool any = false;
        for (auto const& entry : std::filesystem::directory_iterator(dir, ec)) {
            if (ec) break;
            if (!entry.is_regular_file() || entry.path().extension() != ".tblib") continue;
            std::ifstream f(entry.path(), std::ios::binary);
            std::string header;
            std::getline(f, header);
            if (header != "TBLIB 2") continue;
            out << "\n• " << entry.path().filename().string();
            any = true;
        }
        if (!any) out << "\nNo custom templates found.";
        return out.str();
    }
}

class $modify(AutoDecoEditorUI, EditorUI) {
    struct Fields {
        CCMenu* autoDecoMenu = nullptr;
    };

    bool init(LevelEditorLayer* editorLayer) {
        if (!EditorUI::init(editorLayer)) return false;

        auto winSize = CCDirector::sharedDirector()->getWinSize();
        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});
        menu->setID("auto-deco-menu");

        auto makeButton = [&](char const* title, SEL_MenuHandler callback, float y) {
            auto label = CCLabelBMFont::create(title, "bigFont.fnt");
            auto button = CCMenuItemLabel::create(label, this, callback);
            button->setScale(0.42f);
            button->setPosition({winSize.width - 58.f, y});
            menu->addChild(button);
        };

        makeButton("AUTO DECO", menu_selector(AutoDecoEditorUI::onAutoDecoInfo), winSize.height - 82.f);
        makeButton("TEMPLATE", menu_selector(AutoDecoEditorUI::onTemplateInfo), winSize.height - 112.f);
        makeButton("FULL BUILD", menu_selector(AutoDecoEditorUI::onFullBuild), winSize.height - 142.f);
        makeButton("SELECTED", menu_selector(AutoDecoEditorUI::onSelectedBuild), winSize.height - 172.f);

        this->addChild(menu, 1000);
        m_fields->autoDecoMenu = menu;
        return true;
    }

    void onAutoDecoInfo(CCObject*) {
        FLAlertLayer::create(
            "Auto Deco v0.1",
            "Tech template prototype is loaded.\n\nUse TEMPLATE to see import instructions.\nFULL BUILD and SELECTED are interface placeholders until the TBLIB generation engine is implemented.",
            "OK"
        )->show();
    }

    void onTemplateInfo(CCObject*) {
        auto imported = listImportedTemplates();
        FLAlertLayer::create(
            "Templates",
            ("Built-in: Tech" + imported +
             "\n\nTo import another compatible template, place its .tblib file in: " +
             (Mod::get()->getSaveDir() / "templates").string()).c_str(),
            "OK"
        )->show();
    }

    void onFullBuild(CCObject*) {
        FLAlertLayer::create(
            "Full Build",
            "The full-level button is in place, but automatic object generation is not implemented yet. The .tblib files use Autobuild's template format and need its generation algorithm to apply them correctly.",
            "OK"
        )->show();
    }

    void onSelectedBuild(CCObject*) {
        FLAlertLayer::create(
            "Selected Build",
            "The selected-area button is in place, but selection capture and template generation are not implemented yet.",
            "OK"
        )->show();
    }
};
