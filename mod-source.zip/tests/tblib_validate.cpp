#include "../src/tblib_engine.hpp"
#include <iostream>
int main(int argc, char** argv) {
    if (argc < 2) { std::cerr << "Usage: tblib_validate <file.tblib> [file2.tblib ...]\n"; return 2; }
    for (int i = 1; i < argc; ++i) {
        auto data = autodeco::loadTemplate(argv[i]);
        if (!data) { std::cerr << argv[i] << ": FAIL: " << data.error << '\n'; return 1; }
        autodeco::Bounds target;
        target.include(0.f, 0.f);
        target.include(4000.f, 2400.f);
        auto generated = autodeco::generate(data, target);
        if (generated.size() != data.objects.size()) {
            std::cerr << argv[i] << ": FAIL: object count changed during transform\n";
            return 1;
        }
        std::cout << argv[i] << ": OK, " << data.objects.size() << " objects\n";
    }
    return 0;
}
