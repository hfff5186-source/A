# v1.0.0

- First release: auto edges and outer corners for selected solid blocks
