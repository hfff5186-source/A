#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <fstream>
#include <limits>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

namespace autodeco {
struct Point { float x = 0.f, y = 0.f; };
struct Bounds {
    float minX = std::numeric_limits<float>::max();
    float minY = std::numeric_limits<float>::max();
    float maxX = std::numeric_limits<float>::lowest();
    float maxY = std::numeric_limits<float>::lowest();
    bool valid = false;
    void include(float x, float y) {
        if (!std::isfinite(x) || !std::isfinite(y)) return;
        minX = std::min(minX, x); minY = std::min(minY, y);
        maxX = std::max(maxX, x); maxY = std::max(maxY, y); valid = true;
    }
    float width() const { return valid ? std::max(1.f, maxX - minX) : 1.f; }
    float height() const { return valid ? std::max(1.f, maxY - minY) : 1.f; }
    Point center() const { return {(minX + maxX) * .5f, (minY + maxY) * .5f}; }
};
struct TemplateObject {
    std::string data;
    float x = 0.f, y = 0.f;
};
struct TemplateData {
    std::vector<TemplateObject> objects;
    Bounds bounds;
    std::string error;
    explicit operator bool() const { return error.empty() && !objects.empty() && bounds.valid; }
};

inline bool parseFloat(const std::string& s, float& out) {
    try { size_t used = 0; out = std::stof(s, &used); return used == s.size() && std::isfinite(out); }
    catch (...) { return false; }
}

// GD object strings are comma-separated key/value pairs: key 1 = object ID,
// key 2 = X, key 3 = Y. TBLIB stores those strings on data lines ending in ';'.
inline bool readObject(const std::string& raw, TemplateObject& obj) {
    std::string s = raw;
    while (!s.empty() && (s.back() == ';' || s.back() == '\r' || s.back() == '\n' || s.back() == ' ')) s.pop_back();
    if (s.empty()) return false;
    std::vector<std::string> parts;
    std::stringstream ss(s); std::string token;
    while (std::getline(ss, token, ',')) parts.push_back(token);
    if (parts.size() < 6 || parts.size() % 2 != 0) return false;
    bool hasID = false, hasX = false, hasY = false;
    for (size_t i = 0; i + 1 < parts.size(); i += 2) {
        float value = 0.f;
        if (parts[i] == "1") hasID = parseFloat(parts[i + 1], value) && value > 0.f;
        else if (parts[i] == "2") hasX = parseFloat(parts[i + 1], obj.x);
        else if (parts[i] == "3") hasY = parseFloat(parts[i + 1], obj.y);
    }
    if (!hasID || !hasX || !hasY) return false;
    obj.data = std::move(s);
    return true;
}

inline TemplateData loadTemplate(const std::string& path) {
    TemplateData result;
    std::ifstream in(path, std::ios::binary);
    if (!in) { result.error = "Cannot open template file."; return result; }
    std::string line;
    if (!std::getline(in, line)) {
        result.error = "Empty template file."; return result;
    }
    if (!line.empty() && line.back() == '\r') line.pop_back();
    if (line != "TBLIB 2") {
        result.error = "Unsupported TBLIB header (expected TBLIB 2)."; return result;
    }
    size_t lineNo = 1;
    while (std::getline(in, line)) {
        ++lineNo;
        if (line.empty() || line == "---" || line.find(',') == std::string::npos) continue;
        // Some library records can contain multiple serialized objects separated by ';'.
        std::stringstream records(line); std::string record;
        while (std::getline(records, record, ';')) {
            TemplateObject obj;
            if (!readObject(record, obj)) continue;
            result.bounds.include(obj.x, obj.y);
            result.objects.push_back(std::move(obj));
        }
    }
    if (result.objects.empty()) result.error = "No valid Geometry Dash objects were found in this TBLIB file.";
    else if (!result.bounds.valid) result.error = "Template has no usable coordinate bounds.";
    return result;
}

inline std::string replacePair(const std::string& source, int wantedKey, float value) {
    std::vector<std::string> parts;
    std::stringstream ss(source); std::string token;
    while (std::getline(ss, token, ',')) parts.push_back(token);
    if (parts.size() % 2) return {};
    bool replaced = false;
    std::ostringstream out;
    out.setf(std::ios::fixed); out.precision(3);
    for (size_t i = 0; i < parts.size(); i += 2) {
        if (i) out << ',';
        out << parts[i] << ',';
        if (parts[i] == std::to_string(wantedKey)) { out << value; replaced = true; }
        else out << parts[i + 1];
    }
    return replaced ? out.str() : std::string{};
}

inline std::string multiplyPairIfPresent(const std::string& source, int wantedKey, float factor) {
    std::vector<std::string> parts;
    std::stringstream ss(source); std::string token;
    while (std::getline(ss, token, ',')) parts.push_back(token);
    if (parts.size() % 2) return source;
    std::ostringstream out; out.setf(std::ios::fixed); out.precision(3);
    for (size_t i = 0; i < parts.size(); i += 2) {
        if (i) out << ',';
        out << parts[i] << ',';
        if (parts[i] == std::to_string(wantedKey)) {
            float value = 1.f;
            if (parseFloat(parts[i + 1], value)) out << value * factor;
            else out << parts[i + 1];
        } else out << parts[i + 1];
    }
    return out.str();
}

inline std::string transformObject(const TemplateObject& obj, const Bounds& source,
                                    const Bounds& target, float scale) {
    const Point sc = source.center(), tc = target.center();
    const float x = tc.x + (obj.x - sc.x) * scale;
    const float y = tc.y + (obj.y - sc.y) * scale;
    std::string out = replacePair(obj.data, 2, x);
    if (out.empty()) return {};
    out = replacePair(out, 3, y);
    if (out.empty()) return {};
    // Scale the object and axis multipliers when those fields exist.
    for (int key : {32, 128, 129}) out = multiplyPairIfPresent(out, key, scale);
    return out;
}

inline std::vector<std::string> generate(const TemplateData& data, const Bounds& target) {
    std::vector<std::string> out;
    if (!data || !target.valid) return out;
    // Keep the aspect ratio; a modest cap prevents unexpectedly enormous objects.
    float scale = std::min(target.width() / data.bounds.width(), target.height() / data.bounds.height());
    scale = std::clamp(scale, 0.15f, 1.75f);
    out.reserve(data.objects.size());
    for (auto const& obj : data.objects) {
        auto transformed = transformObject(obj, data.bounds, target, scale);
        if (!transformed.empty()) out.push_back(std::move(transformed));
    }
    return out;
}
} // namespace autodeco
